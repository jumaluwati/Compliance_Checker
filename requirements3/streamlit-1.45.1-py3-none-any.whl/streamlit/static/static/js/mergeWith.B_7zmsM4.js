import{aO as u,aP as m,g as h}from"./index.C1z8KpLA.js";var e,r;function W(){if(r)return e;r=1;var t=u(),a=m(),i=a(function(s,g,n,o){t(s,g,n,o)});return e=i,e}var c=W();const v=h(c);export{v as m};
